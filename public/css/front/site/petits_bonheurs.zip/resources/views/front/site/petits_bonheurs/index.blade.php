@include("front.gallery")
@extends('layouts.front.site.' . $theme . '.master-with-breadcrumb')

{{-- @section('title', isset($company->name) ? ucfirst(Formatter::remove_accents($company->name)) : "Site")--}}

{{-- @section('breadcrumb-title')
    {{ strtoupper(Formatter::remove_accents($company->name)) }}
@stop--}}

@section('breadcrumb')
    {{-- {!! Breadcrumbs::render('front.site', $company) !!} --}}
@stop

@section('main-content')
    @if( isset($medias) )
        @if( $medias->where('gslider', 1)->count() > 0 )

        <div class="slider-section" >

            <div id="slider-style-1" class="carousel slide" data-ride="carousel" style="max-height:{{ $company->slideshow_height }}px!important;">
                    <ol class="carousel-indicators">
                      @for ($i = 0; $i < $medias->where('gslider', 1)->count(); $i++)
                        <li data-target="#slider-style-1 data-slide-to="{{ $i }}"
                          class="@if ($i === 0) active @endif">
                        </li>
                        @endfor

                    </ol>
                    <div class="carousel-inner" role="listbox">

                            <?php $loop = 0; ?>
                            @foreach( $medias->where('gslider', 1) as $media)
    
                                <div class="carousel-item" @if ($loop === 0) active @endif">
                                    @if ($media->target != '')
                                        <a target="_blank" href="{{ $media->target }}">
                                            @endif
                                            @if ($media->photo)
                                                <img class="d-block img-fluid" alt="{{ $media->name }}"
                                                     title="{{ $media->name }} - {{ strtoupper($company->name) }}"
                                                     src="{!! URL::asset('uploads/galleries/' . $media->gallery_id . '/' . $media->slug) !!}"
                                                     alt="{{ $media->id }}" style="max-height:{{ $company->slideshow_height }}px!important;">
                                                @if ($media->target != '')
                                                </a>
                                                @endif
                                            @else
                                                <iframe class="carousel-video"
                                                src="{{ App\Helpers\Formatter::getYoutubeEmbed($media->slug) }}"
                                                allowfullscreen="" width="100%" height="100%" frameborder="0"></iframe>
                                            @endif
                                    <div class="carousel-caption">
                                        <h3>{{ $media->name }}</h3>
                                        <h4>
                                            @if( $media->content != '' ) 
                                                {{ $media->content }}
                                            @endif
                                        </h4>
                                        @if( $media->target != '' )
                                           
                                                <a href="{{ $media->target }}" target="_blank"> En savoir plus </a>
                                            
                                        @endif
                                    </div>
                                </div>
                            <?php $loop ++; ?>
                            @endforeach
                    </div>
                    <a class="carousel-control-prev" href="#slider-style-1" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#slider-style-1" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                </div>

            </div>
        @endif
    @endif


    <!-- content -->
<div id="home-content-section">
    <div class="container">
      <div class="row">
            <div class="content col-md-10">
                {!! $company->home_content !!}
            </div>
      </div>
    </div>
</div>
<!-- end content -->

<?php/*
    <div class="container">
        <div class="row">

            <div id="main" class="col-md-12">

                <div class="" id="main-content">

                    {!! $company->home_content !!}

                    <!-- Tourisme -->
                {{--@if (isset($activities) && $activities->where('type_id', 1)->count() > 0)
                        <div id="tourisme-tab" class="tab-pane">
                            <table class='table table-striped'>
                                <tr>
                                    <th>Activité</th>
                                    <th>Catégorie</th>
                                </tr>
                                @foreach($activities->where('type_id', 1)->sortBy('category_name')->all() as $activity)
                                    <tr>
                                        <td>{{$activity->name}}</td>
                                        <td>{{$activity->category_name}}</td>
                                    </tr>
                                @endforeach
                            </table>
                        </div>
                    @endif --}}
                <!-- Sliders -->



                <!-- <div id="index_newsletter">
        <h3>Infolettre</h3>
        <p>Inscrivez-vous à notre infolettre dès maintenant!</p>
{{-- {{ Form::open(array('route' => array('front.company.newsletter.subscribe.post', $company->id), 'method' => 'POST', 'id' => 'signupForm', 'class' => 'form-horizontal form-groups-bordered', 'autocomplete' => 'off')) }}
          {{ Form::text('name', null, ['class' => 'form-control', 'min'=>3, 'placeholder' => 'Votre nom...', 'id' => 'name']) }}
          {{ Form::text('mail', null, ['class' => 'form-control', 'min'=>6, 'placeholder' => 'Votre adresse courriel...', 'id' => 'mail']) }}
          <br>
          {!! Form::submit('S\'abonner à notre infolettre', array('class'=>'send-btn')) !!}
          {!! app('captcha')->render($lang = 'fr'); !!}
        {{ Form::close() }} --}}

                        </div>-->

                    <div class="clearfix"></div>

                    <!-- Medias 
                    <div class="wrap-galerie">
                        @if ($company->gallery_home == 0)
                            @if (isset($medias) && $medias->where('gslider', null)->count() > 0 )
                                <h2 class="separator">Galeries</h2>
                                @yield('gallery')
                            @endif
                        @endif
                    </div>
-->
                    <!-- Affaire -->
                    @if (isset($activities) && $activities->where('type_id', 2)->count() > 0)
                        <div id="affaire-tab" class="tab-pane">
                            <table class='table table-striped'>
                                <tr>
                                    <th>Activité</th>
                                    <th>Catégorie</th>
                                </tr>
                                @foreach($activities->where('type_id', 2)->sortBy('category_name')->all() as $activity)
                                    <tr>
                                        <td>{{$activity->name}}</td>
                                        <td>{{$activity->category_name}}</td>
                                    </tr>
                                @endforeach
                            </table>
                        </div>
                    @endif

                </div>
            </div>
        </div>
    </div>
   
*/?>
@stop
@section('js')

    <script type="text/javascript">
        jQuery(document).ready(function () {

            $('#signupForm').submit(function (e) {
                if ($(this).find('#email').val() == '') {
                    e.preventDefault();
                    alert('Erreur: veuillez entrer votre adresse courriel valide.');
                }
            });

        });
        jQuery(document).ready(function () {
            amazonmenu.init({
                menuid: 'demo'
            })
        })
        jQuery(document).ready(function () {
            amazonmenu.init({
                animateduration: 100,
                showhidedelay: [100, 100],
                hidemenuonclick: true
            });
        });
        jQuery(document).ready(function () {

            $('.center').slick({
                centerMode: true,
                centerPadding: '15px',
                slidesToShow: 6,
                autoplay: true,
                responsive: [
                    {
                        breakpoint: 768,
                        settings: {
                            arrows: false,
                            centerMode: true,
                            centerPadding: '40px',
                            slidesToShow: 3
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            arrows: false,
                            centerMode: true,
                            centerPadding: '40px',
                            slidesToShow: 1
                        }
                    }
                ]
            });

        });

    </script>

@stop
